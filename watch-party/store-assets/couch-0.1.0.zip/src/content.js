/*
 * Couch — content script (isolated world) running on netflix.com/watch/*.
 *
 * Serverless architecture (no backend to host):
 *   - Signaling runs over the free PeerJS public cloud broker (wss). The party
 *     creator registers a deterministic peer id `couch-<ROOMCODE>` and acts as
 *     the rendezvous/discovery point. Joiners reach that id with just the code.
 *   - Once peers discover each other they form a full WebRTC mesh: a data
 *     channel per pair carries playback sync (everyone shares controls) and a
 *     media call per pair carries the audio/video.
 *
 * PeerJS is vendored and loaded as a content script before this file, exposing
 * the global `Peer`.
 */
(function () {
  'use strict';

  if (window.__couchContent) return;
  window.__couchContent = true;

  const ICE_SERVERS = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ];

  const state = {
    brokerHost: '',          // '' => PeerJS public cloud
    peer: null,
    peerId: null,
    isHost: false,
    room: null,
    hostId: null,
    name: 'Guest',
    inParty: false,
    connected: false,        // registered with the broker
    micOn: true,
    camOn: true,
    localStream: null,
    members: new Map(),       // peerId -> { name, dataConn, call, stream, tile }
    lastAppliedAt: 0,
  };

  // ------------------------------------------------------------------ utils ---

  const log = (...a) => console.debug('%c[Couch]', 'color:#0FB5A3', ...a);

  function randomId(n = 8) {
    const c = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
    let s = '';
    for (let i = 0; i < n; i++) s += c[Math.floor(Math.random() * c.length)];
    return s;
  }

  function hostIdFor(room) { return 'couch-' + room.toUpperCase(); }

  function memberStatus() {
    return [state.name, ...[...state.members.values()].map((m) => m.name)];
  }

  function saveStatus() {
    const status = {
      inParty: state.inParty, connected: state.connected, room: state.room,
      name: state.name, micOn: state.micOn, camOn: state.camOn, members: memberStatus(),
    };
    try {
      chrome.storage.local.set({ couchStatus: status });
      chrome.runtime.sendMessage({ type: 'status', status }).catch(() => {});
    } catch (e) {}
  }

  // --------------------------------------------------------- page bridge ------

  function injectPageScript() {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('src/injected.js');
    s.onload = () => s.remove();
    (document.head || document.documentElement).appendChild(s);
  }

  function sendToPage(msg) {
    window.postMessage(Object.assign({ source: 'couch-content' }, msg), '*');
  }

  // Local playback events from the page -> broadcast to peers.
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const d = event.data;
    if (!d || d.source !== 'couch-page') return;
    if (d.type === 'state' && state.inParty) {
      if (Date.now() - state.lastAppliedAt < 400) return; // don't echo applied state
      broadcast({ t: 'sync', action: d.action, paused: d.paused, timeMs: d.timeMs });
    }
  });

  // ------------------------------------------------------- PeerJS plumbing ----

  function peerOptions() {
    const opts = { debug: 1, config: { iceServers: ICE_SERVERS } };
    if (state.brokerHost) {
      // Accept "host", "host:port" or "wss://host:port/path".
      let h = state.brokerHost.replace(/^wss?:\/\//, '');
      let path = '/';
      const slash = h.indexOf('/');
      if (slash !== -1) { path = h.slice(slash); h = h.slice(0, slash); }
      const [host, port] = h.split(':');
      opts.host = host;
      opts.port = port ? Number(port) : 443;
      opts.path = path;
      opts.secure = true;
    }
    return opts;
  }

  function initPeer() {
    const peer = new Peer(state.peerId, peerOptions());
    state.peer = peer;

    peer.on('open', (id) => {
      state.peerId = id;
      state.connected = true;
      log('broker open as', id, state.isHost ? '(host)' : '(joiner)');
      if (!state.isHost) connectData(state.hostId); // bootstrap discovery
      toast(state.isHost ? 'Party ready — share the code' : 'Joined — connecting…');
      render(); saveStatus();
    });

    peer.on('connection', (conn) => setupDataConn(conn, /*incoming*/ true));

    peer.on('call', (call) => {
      ensureMember(call.peer, (call.metadata && call.metadata.name));
      call.answer(state.localStream || new MediaStream());
      setupCall(call);
    });

    peer.on('disconnected', () => {
      state.connected = false; saveStatus();
      if (state.inParty) { try { peer.reconnect(); } catch (e) {} }
    });

    peer.on('error', (err) => {
      log('peer error', err && err.type, err && err.message);
      if (err && err.type === 'unavailable-id') {
        toast('That code is taken — try creating again');
      } else if (err && err.type === 'peer-unavailable') {
        toast('Party not found — check the invite code');
      } else if (err && err.type === 'network') {
        toast('Signaling network hiccup — retrying…');
      }
    });
  }

  // ------------------------------------------------------- mesh formation -----

  function ensureMember(peerId, name) {
    if (peerId === state.peerId) return null;
    let m = state.members.get(peerId);
    if (!m) {
      m = { name: name || 'Guest', dataConn: null, call: null, stream: null, tile: null };
      state.members.set(peerId, m);
    } else if (name) {
      m.name = name;
    }
    return m;
  }

  // Lower peer id initiates, so exactly one side opens each connection.
  function iInitiateTo(peerId) { return state.peerId < peerId; }

  function connectData(peerId) {
    if (peerId === state.peerId) return;
    const m = ensureMember(peerId);
    if (m.dataConn) return;
    const conn = state.peer.connect(peerId, {
      reliable: true, metadata: { name: state.name },
    });
    setupDataConn(conn, /*incoming*/ false);
  }

  function ensureData(peerId) {
    const m = ensureMember(peerId);
    if (!m || m.dataConn) return;
    if (iInitiateTo(peerId)) connectData(peerId);
    // else: wait for them to connect to us
  }

  function ensureMedia(peerId) {
    const m = ensureMember(peerId);
    if (!m || m.call) return;
    if (iInitiateTo(peerId)) {
      const call = state.peer.call(peerId, state.localStream || new MediaStream(), {
        metadata: { name: state.name },
      });
      setupCall(call);
    }
    // else: wait for their incoming call
  }

  function setupDataConn(conn, incoming) {
    const peerId = conn.peer;
    const m = ensureMember(peerId, conn.metadata && conn.metadata.name);
    m.dataConn = conn;

    conn.on('open', () => {
      conn.send({ t: 'hello', name: state.name });
      ensureMedia(peerId);

      if (state.isHost && incoming) {
        // A newcomer reached the host. Introduce everyone.
        const others = [...state.members.entries()]
          .filter(([id]) => id !== peerId)
          .map(([id, mm]) => ({ peerId: id, name: mm.name }));
        conn.send({ t: 'welcome', members: others });
        broadcastExcept(peerId, { t: 'peer-joined', peerId, name: m.name });
      }
      render(); saveStatus();
    });

    conn.on('data', (msg) => handleData(peerId, msg));

    conn.on('close', () => dropMember(peerId, /*announce*/ state.isHost));
    conn.on('error', () => dropMember(peerId, /*announce*/ state.isHost));
  }

  function handleData(fromId, msg) {
    if (!msg || typeof msg !== 'object') return;
    switch (msg.t) {
      case 'hello':
        ensureMember(fromId, msg.name); render(); saveStatus();
        break;
      case 'welcome':
        // From the host: connect to every other existing member.
        (msg.members || []).forEach((p) => {
          ensureMember(p.peerId, p.name);
          ensureData(p.peerId);
          ensureMedia(p.peerId);
        });
        ensureMedia(fromId); // also bring up media with the host
        sendTo(fromId, { t: 'sync-request' });
        render();
        break;
      case 'peer-joined':
        ensureMember(msg.peerId, msg.name);
        ensureData(msg.peerId);
        ensureMedia(msg.peerId);
        toast(`${msg.name} joined`);
        render();
        break;
      case 'peer-left':
        dropMember(msg.peerId, false);
        break;
      case 'sync':
        applyRemoteSync(msg);
        break;
      case 'sync-request':
        sendToPage({ type: 'request-state' });
        break;
    }
  }

  function setupCall(call) {
    const peerId = call.peer;
    const m = ensureMember(peerId, call.metadata && call.metadata.name);
    m.call = call;
    call.on('stream', (stream) => { m.stream = stream; renderPeerTile(peerId, m); });
    call.on('close', () => { m.call = null; });
    call.on('error', () => { m.call = null; });
  }

  function dropMember(peerId, announce) {
    const m = state.members.get(peerId);
    if (!m) return;
    try { if (m.call) m.call.close(); } catch (e) {}
    try { if (m.dataConn) m.dataConn.close(); } catch (e) {}
    if (m.tile) m.tile.remove();
    state.members.delete(peerId);
    if (announce) broadcast({ t: 'peer-left', peerId });
    render(); saveStatus();
  }

  // ----------------------------------------------------------- messaging ------

  function sendTo(peerId, obj) {
    const m = state.members.get(peerId);
    if (m && m.dataConn && m.dataConn.open) m.dataConn.send(obj);
  }
  function broadcast(obj) {
    state.members.forEach((m) => { if (m.dataConn && m.dataConn.open) m.dataConn.send(obj); });
  }
  function broadcastExcept(exceptId, obj) {
    state.members.forEach((m, id) => {
      if (id !== exceptId && m.dataConn && m.dataConn.open) m.dataConn.send(obj);
    });
  }

  function applyRemoteSync(msg) {
    state.lastAppliedAt = Date.now();
    sendToPage({
      type: 'command',
      cmd: { action: msg.action === 'sync' ? (msg.paused ? 'pause' : 'play') : msg.action,
             timeMs: msg.timeMs },
    });
  }

  // ------------------------------------------------------------ local media ---

  async function ensureLocalStream() {
    if (state.localStream) return state.localStream;
    try {
      state.localStream = await navigator.mediaDevices.getUserMedia({
        audio: true, video: { width: 320, height: 240 },
      });
    } catch (e) {
      toast('Mic/camera blocked — joining in listen-only mode');
      state.localStream = new MediaStream();
    }
    applyTrackToggles();
    renderLocalTile();
    return state.localStream;
  }

  function applyTrackToggles() {
    if (!state.localStream) return;
    state.localStream.getAudioTracks().forEach((t) => (t.enabled = state.micOn));
    state.localStream.getVideoTracks().forEach((t) => (t.enabled = state.camOn));
  }

  // ------------------------------------------------------------ overlay UI ----

  let ui = null;

  function buildOverlay() {
    if (ui) return ui;
    const root = document.createElement('div');
    root.id = 'couch-overlay';
    root.innerHTML = `
      <div class="lv-header">
        <span class="lv-logo">Couch</span>
        <span class="lv-room"></span>
        <button class="lv-collapse" title="Collapse">–</button>
      </div>
      <div class="lv-tiles"></div>
      <div class="lv-controls">
        <button class="lv-btn lv-mic"   title="Mute / unmute">🎤</button>
        <button class="lv-btn lv-cam"   title="Camera on / off">📷</button>
        <button class="lv-btn lv-sync"  title="Resync everyone to my position">⟳</button>
        <button class="lv-btn lv-copy"  title="Copy invite code">⧉</button>
        <button class="lv-btn lv-leave" title="Leave party">⏻</button>
      </div>
      <div class="lv-status"></div>`;
    document.documentElement.appendChild(root);

    root.querySelector('.lv-collapse').onclick = () => root.classList.toggle('lv-collapsed');
    root.querySelector('.lv-mic').onclick = toggleMic;
    root.querySelector('.lv-cam').onclick = toggleCam;
    root.querySelector('.lv-sync').onclick = forceResync;
    root.querySelector('.lv-copy').onclick = () => {
      navigator.clipboard.writeText(state.room).then(() => toast('Invite code copied'));
    };
    root.querySelector('.lv-leave').onclick = leaveParty;

    makeDraggable(root, root.querySelector('.lv-header'));
    ui = root;
    return root;
  }

  function makeDraggable(el, handle) {
    let dx = 0, dy = 0, dragging = false;
    handle.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      dragging = true;
      dx = e.clientX - el.offsetLeft;
      dy = e.clientY - el.offsetTop;
      e.preventDefault();
    });
    window.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      el.style.left = Math.max(0, e.clientX - dx) + 'px';
      el.style.top = Math.max(0, e.clientY - dy) + 'px';
      el.style.right = 'auto';
    });
    window.addEventListener('mouseup', () => (dragging = false));
  }

  function renderLocalTile() {
    const root = buildOverlay();
    const tiles = root.querySelector('.lv-tiles');
    let tile = tiles.querySelector('.lv-tile-local');
    if (!tile) {
      tile = document.createElement('div');
      tile.className = 'lv-tile lv-tile-local';
      tile.innerHTML = `<video autoplay playsinline muted></video><span class="lv-name">You</span>`;
      tiles.prepend(tile);
    }
    const v = tile.querySelector('video');
    if (state.localStream && v.srcObject !== state.localStream) v.srcObject = state.localStream;
    tile.classList.toggle('lv-camoff', !state.camOn);
  }

  function renderPeerTile(peerId, m) {
    const root = buildOverlay();
    const tiles = root.querySelector('.lv-tiles');
    if (!m.tile) {
      m.tile = document.createElement('div');
      m.tile.className = 'lv-tile';
      m.tile.innerHTML = `<video autoplay playsinline></video><span class="lv-name"></span>`;
      tiles.appendChild(m.tile);
    }
    m.tile.querySelector('.lv-name').textContent = m.name;
    const v = m.tile.querySelector('video');
    if (m.stream && v.srcObject !== m.stream) v.srcObject = m.stream;
  }

  function render() {
    const root = buildOverlay();
    root.querySelector('.lv-room').textContent = state.room ? `#${state.room}` : '';
    const n = state.members.size + 1;
    root.querySelector('.lv-status').textContent =
      `${state.connected ? '🟢' : '🔴'} ${n} watching`;
    root.querySelector('.lv-mic').classList.toggle('lv-off', !state.micOn);
    root.querySelector('.lv-cam').classList.toggle('lv-off', !state.camOn);
    renderLocalTile();
    state.members.forEach((m, id) => renderPeerTile(id, m));
  }

  let toastTimer = null;
  function toast(text) {
    const root = buildOverlay();
    let t = root.querySelector('.lv-toast');
    if (!t) { t = document.createElement('div'); t.className = 'lv-toast'; root.appendChild(t); }
    t.textContent = text;
    t.classList.add('lv-show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('lv-show'), 2500);
  }

  // ------------------------------------------------------------ controls ------

  function toggleMic() { state.micOn = !state.micOn; applyTrackToggles(); render(); saveStatus(); }
  function toggleCam() { state.camOn = !state.camOn; applyTrackToggles(); render(); saveStatus(); }
  function forceResync() { sendToPage({ type: 'request-state' }); toast('Resyncing everyone…'); }

  // ------------------------------------------------------- party lifecycle ----

  async function startParty({ room, name, brokerHost, host }) {
    state.room = (room || randomId()).toUpperCase();
    state.name = name || state.name || 'Guest';
    state.brokerHost = brokerHost || '';
    state.isHost = !!host;
    state.hostId = hostIdFor(state.room);
    // Host owns the rendezvous id; joiners get a unique random id.
    state.peerId = host ? state.hostId : 'couch-' + randomId(10);
    state.inParty = true;
    await ensureLocalStream();
    initPeer();
    render(); saveStatus();
    return { room: state.room };
  }

  function leaveParty() {
    state.inParty = false;
    broadcast({ t: 'peer-left', peerId: state.peerId });
    [...state.members.keys()].forEach((id) => dropMember(id, false));
    try { if (state.peer) state.peer.destroy(); } catch (e) {}
    state.peer = null; state.connected = false;
    if (state.localStream) state.localStream.getTracks().forEach((t) => t.stop());
    state.localStream = null;
    if (ui) { ui.remove(); ui = null; }
    state.room = null; state.hostId = null;
    saveStatus();
  }

  // --------------------------------------------------- popup <-> content ------

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    (async () => {
      switch (msg.type) {
        case 'get-status':
          sendResponse({
            inParty: state.inParty, connected: state.connected, room: state.room,
            name: state.name, micOn: state.micOn, camOn: state.camOn, members: memberStatus(),
          });
          break;
        case 'create-party':
          sendResponse(await startParty({ room: randomId(), name: msg.name,
            brokerHost: msg.brokerHost, host: true }));
          break;
        case 'join-party':
          sendResponse(await startParty({ room: msg.room, name: msg.name,
            brokerHost: msg.brokerHost, host: false }));
          break;
        case 'leave-party': leaveParty(); sendResponse({ ok: true }); break;
        case 'toggle-mic': toggleMic(); sendResponse({ micOn: state.micOn }); break;
        case 'toggle-cam': toggleCam(); sendResponse({ camOn: state.camOn }); break;
        default: sendResponse({});
      }
    })();
    return true;
  });

  // ----------------------------------------------------------- bootstrap ------

  chrome.storage.local.get(['couchBrokerHost', 'couchName'], (cfg) => {
    if (cfg.couchBrokerHost) state.brokerHost = cfg.couchBrokerHost;
    if (cfg.couchName) state.name = cfg.couchName;
  });

  injectPageScript();
  log('content script ready on', location.href);
})();
